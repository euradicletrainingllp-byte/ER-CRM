/**
 * Operations dashboard — rebuilt 7 Nov 2026 as an operations-intelligence view:
 *   KPIs (vs last FY same date) · insight alerts · next-30-day readiness · monthly rhythm · day heatmap ·
 *   consultant load · client portfolio · mode / service / feedback mix · History (FY trend, YoY, feedback log, collapsed).
 *
 *   FY 2026-27 onward  → live from the Engagement Calendar
 *   Earlier years      → fixed numbers from Dashboard Report Data (12 Oct 2026), see dashboardBaseline.js
 *
 * Live definitions
 *   Delivered   Status = Delivered
 *   Upcoming    Status Scheduled / Tentative / Re-Schedule with a start date from today onward
 *   Project     unique EG ID ("Count by → Sessions" counts calendar rows instead)
 *   Days        the "Day" column, credited to every consultant on the session
 *   Mode        Location VILT / Virtual / Online → Virtual, any other place → In-Person
 *   Feedback    "Feedback" column when it is a score between 0 and 5
 */
import { useMemo, useState } from 'react';
import {
  ChartBox, Kpi, SourceNote, NV, TL, GD, GN, PU, RD, bOpts, dlNum, dlH, fmtNum, heightFor,
  CURRENT_FY, fyStartOf, fyShort, fyLong, todayISO, clean, keyOf,
} from './erdCharts.jsx';
import { LIVE_FROM_FY, OPS_FY, OPS_CONSULTANT_PREV, OPS_CLIENT_PREV, OPS_FEEDBACK } from '../config/dashboardBaseline.js';

const NOT_A_PERSON = /^(euradicle|er pmo team|tbd|na|n\/a|-|—)$/i;
const isDelivered = e => /^delivered$/i.test(clean(e.status));
const hasDate = e => /^\d{4}-\d{2}-\d{2}$/.test(e.startDate || '');
const isCancelled = e => /cancel|lost|drop|postpon|hold/i.test(clean(e.status));
// Dates TBD: a row with an Index / S No that is not delivered or cancelled is an upcoming engagement
const isUpcoming  = e => (hasDate(e)
  ? /^(scheduled|tentative|re-?schedule)$/i.test(clean(e.status)) && e.startDate >= todayISO
  : !isDelivered(e) && !isCancelled(e));
const daysOf = e => (Number(e.day) > 0 ? Number(e.day) : 0);
import KpiListModal, { egItem } from './KpiListModal.jsx';
const consultantsOf = e => [...new Set([e.consultant1, e.consultant2, e.consultant3].map(clean).filter(n => n && !NOT_A_PERSON.test(n)))];
const modeOf = e => {
  const raw = clean(e.locationRaw ?? e.location);
  if (!raw || raw === '#VALUE!') return 'unknown';
  return /vilt|virtual|online|zoom|teams|webinar/i.test(raw) ? 'virtual' : 'inPerson';
};
const feedbackOf = e => { const n = Number(clean(e.feedback)); return n > 0 && n <= 5 ? n : null; };
const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fmtDate = iso => (iso ? `${+iso.slice(8, 10)} ${MON[+iso.slice(5, 7) - 1]} ${iso.slice(0, 4)}` : '—');

/** Counts unique EG IDs (projects) or rows (sessions) per key. */
function counter(countBy) {
  const m = new Map();
  return {
    add(k, e) {
      if (!m.has(k)) m.set(k, countBy === 'projects' ? new Set() : { size: 0, add() { this.size++; } });
      m.get(k).add(clean(e.egId) || `row-${e.sno}`);
    },
    get: k => m.get(k)?.size || 0,
  };
}

/** Horizontal one-colour bar charts, one per year, sharing the same x-axis. */
function MiniYearCharts({ blocks, palette, unit, titleOf }) {
  const configs = useMemo(() => {
    const sorted = blocks.map(b => b.data.slice().sort((a, c) => c[1] - a[1]));
    const max = Math.max(0, ...sorted.flat().map(d => d[1]));
    const axisMax = max > 0 ? Math.ceil(max * 1.12) : 1;
    return blocks.map((b, i) => {
      const opts = { ...bOpts(false, true), indexAxis: 'y', plugins: { legend: { display: false }, datalabels: dlH() } };
      opts.scales = { ...opts.scales, x: { ...opts.scales.x, min: 0, max: axisMax }, y: { ...opts.scales.y, ticks: { font: { size: 12 }, autoSkip: false } } };
      const total = sorted[i].reduce((s, d) => s + d[1], 0);
      return {
        title: titleOf(b, total, sorted[i].length),
        height: heightFor(sorted[i].length, 24),
        cfg: { type: 'bar', options: opts, data: {
          labels: sorted[i].map(d => d[0]),
          datasets: [{ label: unit, data: sorted[i].map(d => d[1]), backgroundColor: palette[i % palette.length], borderRadius: 3 }],
        } },
      };
    });
  }, [blocks, palette, unit, titleOf]);
  return (
    <div className="mini-chart-grid" style={{ gridTemplateColumns: `repeat(${Math.max(blocks.length, 1)},1fr)` }}>
      {configs.map(c => (
        <div className="mini-chart-col" key={c.title}>
          <div className="mini-chart-title">{c.title}</div>
          <ChartBox config={c.cfg} className="ch-wrap tall" height={c.height} />
        </div>
      ))}
    </div>
  );
}

const PREV_DAYS_PALETTE = [TL, GD, NV, PU, GN, RD];
const PREV_CLIENT_PALETTE = [NV, TL, GD, PU, GN, RD];
const titleDays = (b, tot) => `${b.label} · ${fmtNum(Math.round(tot * 100) / 100)} days`;
const titleClients = (b, tot, n) => `${b.label} · ${tot} projects, ${n} clients`;

export default function OpsLiveDashboard({ engagements, refreshing }) {
  const [countBy, setCountBy] = useState('projects');
  const unit = countBy === 'projects' ? 'Projects' : 'Sessions';

  // Live rows: usable start date and FY from LIVE_FROM_FY onward
  // Every EC row with a date, or with an Index / S No and dates TBD (counted in the current FY)
  const all = useMemo(() => (engagements || [])
    .filter(e => hasDate(e) || ((clean(e.engagementKey) || clean(e.sno)) && (clean(e.company) || clean(e.topic))))
    .map(e => ({ ...e, fy: hasDate(e) ? fyStartOf(e.startDate) : CURRENT_FY })), [engagements]);
  const live = useMemo(() => all.filter(e => e.fy >= LIVE_FROM_FY), [all]);
  const cur = useMemo(() => live.filter(e => e.fy === CURRENT_FY), [live]);

  /* Financial Year table: fixed years + live years */
  const fyData = useMemo(() => {
    const del = counter(countBy), up = counter(countBy), ip = counter(countBy), vi = counter(countBy);
    all.forEach(e => {
      if (isDelivered(e)) {
        del.add(e.fy, e);
        const m = modeOf(e);
        if (m === 'inPerson') ip.add(e.fy, e); else if (m === 'virtual') vi.add(e.fy, e);
      } else if (isUpcoming(e)) up.add(e.fy, e);
    });
    const liveRows = [];
    for (let y = LIVE_FROM_FY; y <= CURRENT_FY; y++) {
      liveRows.push({ fy: y, inPerson: ip.get(y), virtual: vi.get(y), total: del.get(y), upcoming: up.get(y), live: true });
    }
    const early = OPS_FY.map(b => (del.get(b.fy) > 0 ? { fy: b.fy, inPerson: ip.get(b.fy), virtual: vi.get(b.fy), total: del.get(b.fy), upcoming: 0, live: true } : b));
    return [...early, ...liveRows];
  }, [all, countBy]);

  /* Year-on-year comparison: consultant days / client projects per FY (EC first, baseline when EC has no delivered rows that year) */
  const compare = useMemo(() => {
    const years = [...new Set([...OPS_FY.map(b => b.fy), CURRENT_FY - 2, CURRENT_FY - 1, CURRENT_FY])].filter(y => y >= CURRENT_FY - 3).sort();
    const build = (pick, baseline) => {
      const m = new Map(), from = new Map();
      const put = (name, y, v) => { const k = keyOf(name); if (!m.has(k)) m.set(k, { label: name, v: {} }); const x = m.get(k).v; x[y] = (x[y] || 0) + v; };
      all.forEach(e => { if (years.includes(e.fy) && (isDelivered(e) || (e.fy === CURRENT_FY && isUpcoming(e)))) { from.set(e.fy, true); pick(e).forEach(([n, v]) => put(n, e.fy, v)); } });
      baseline.forEach(b => { const y = Number(String(b.label).match(/\d{4}/)?.[0]); if (years.includes(y) && !from.get(y)) b.data.forEach(([n, v]) => put(n, y, v)); });
      const rows = [...m.values()].map(r => ({ ...r, tot: years.reduce((t, y) => t + (r.v[y] || 0), 0) })).sort((a, b) => b.tot - a.tot).slice(0, 15);
      const pal = [PU, TL, NV, GD];
      return { rows, cfg: { type: 'bar', data: { labels: rows.map(r => r.label), datasets: years.map((y, i) => ({
          label: fyShort(y) + (y === CURRENT_FY ? ' (incl. upcoming)' : ''), data: rows.map(r => Math.round((r.v[y] || 0) * 100) / 100),
          backgroundColor: y === CURRENT_FY ? GD : pal[i % pal.length], borderRadius: 3 })) },
        options: { ...bOpts(false, false), indexAxis: 'y', plugins: { legend: { position: 'top' }, datalabels: { display: false } } } } };
    };
    const seen = new Set();
    return {
      cons: build(e => consultantsOf(e).map(n => [n, daysOf(e)]), OPS_CONSULTANT_PREV),
      cli: build(e => { const n = clean(e.company), id = clean(e.egId) || `row-${e.sno}`; if (!n || seen.has(id + n)) return []; seen.add(id + n); return [[n, 1]]; }, OPS_CLIENT_PREV),
    };
  }, [all]);

  /* Client status — current FY */
  const clients = useMemo(() => {
    const del = counter(countBy), up = counter(countBy), names = new Map();
    cur.forEach(e => {
      const name = clean(e.company); if (!name) return;
      const k = keyOf(name);
      if (isDelivered(e)) { del.add(k, e); names.set(k, names.get(k) || name); }
      else if (isUpcoming(e)) { up.add(k, e); names.set(k, names.get(k) || name); }
    });
    return [...names.entries()].map(([k, label]) => ({ label, delivered: del.get(k), upcoming: up.get(k) }))
      .sort((a, b) => (b.delivered + b.upcoming) - (a.delivered + a.upcoming));
  }, [cur, countBy]);

  /* Consultant days — current FY */
  const trainers = useMemo(() => {
    const m = new Map();
    cur.forEach(e => {
      const kind = isDelivered(e) ? 'dd' : isUpcoming(e) ? 'du' : null;
      if (!kind) return;
      consultantsOf(e).forEach(n => {
        const k = keyOf(n);
        if (!m.has(k)) m.set(k, { label: n, dd: 0, du: 0 });
        m.get(k)[kind] += daysOf(e);
      });
    });
    return [...m.values()].filter(t => t.dd + t.du > 0).sort((a, b) => (b.dd + b.du) - (a.dd + a.du));
  }, [cur]);

  /* Feedback — fixed list from Excel + live scores per program */
  const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10);
  const fbRows = useMemo(() => {
    const rows = all.filter(e => hasDate(e) && (feedbackOf(e) != null || (isDelivered(e) && e.startDate >= weekAgo && e.startDate <= todayISO)))
      .map(e => ({ key: `${e.engagementKey || e.sno}`, label: clean(e.topic) || '(No topic)', client: clean(e.company), date: e.endDate && hasDate({ startDate: e.endDate }) ? e.endDate : e.startDate, score: feedbackOf(e) }))
      .sort((a, b) => b.date.localeCompare(a.date));
    const scored = rows.filter(r => r.score != null);
    const base = scored.length ? [] : OPS_FEEDBACK.map(([label, score]) => ({ key: 'b-' + label, label, client: '', date: '', score }));
    const list = [...rows, ...base], sc = list.filter(r => r.score != null);
    return { list, avg: sc.length ? sc.reduce((t, r) => t + r.score, 0) / sc.length : 0, n: sc.length, week: rows.filter(r => r.date >= weekAgo).length };
  }, [all, weekAgo]);
  const feedback = useMemo(() => {
    const m = new Map();
    OPS_FEEDBACK.forEach(([label, score]) => m.set(keyOf(label), { label, score, n: null, latest: '' }));
    const g = new Map();
    live.forEach(e => {
      const s = feedbackOf(e); if (s == null) return;
      const label = clean(e.topic) || '(No topic)';
      const k = keyOf(label);
      if (!g.has(k)) g.set(k, { label, sum: 0, n: 0, latest: '' });
      const x = g.get(k); x.sum += s; x.n++; if (e.startDate > x.latest) x.latest = e.startDate;
    });
    g.forEach((x, k) => m.set(k, { label: x.label, score: Math.round((x.sum / x.n) * 100) / 100, n: x.n, latest: x.latest }));
    return [...m.values()].sort((a, b) => b.score - a.score);
  }, [live]);

  /* KPIs */
  const curRow = fyData[fyData.length - 1];
  const best = fyData.reduce((b, r) => (r.total > b.total ? r : b), fyData[0]);
  const keyAccount = clients.slice().sort((a, b) => b.upcoming - a.upcoming)[0];

  /* Chart configs */
  const trendCfg = useMemo(() => {
    const sets = [{ label: 'Total Delivered', data: fyData.map(r => r.total), backgroundColor: fyData.map((r, i) => (i === fyData.length - 1 ? GD : TL)), borderRadius: 5 }];
    if (fyData.some(r => r.upcoming > 0)) sets.push({ label: 'Upcoming', data: fyData.map(r => r.upcoming), backgroundColor: PU, borderRadius: 5 });
    return { type: 'bar', data: { labels: fyData.map(r => fyShort(r.fy)), datasets: sets },
      options: { ...bOpts(false, false), layout: { padding: { top: 16 } }, plugins: { legend: { position: 'top' }, datalabels: dlNum() } } };
  }, [fyData]);

  const modeCfg = useMemo(() => ({ type: 'bar',
    data: { labels: fyData.map(r => fyShort(r.fy)), datasets: [
      { label: 'In-Person', data: fyData.map(r => r.inPerson), backgroundColor: NV, borderRadius: 4 },
      { label: 'Virtual', data: fyData.map(r => r.virtual), backgroundColor: TL, borderRadius: 4 },
    ] },
    options: { ...bOpts(false, false), layout: { padding: { top: 16 } }, plugins: { legend: { position: 'top' }, datalabels: dlNum() } },
  }), [fyData]);

  const clientsCfg = useMemo(() => ({ type: 'bar',
    data: { labels: clients.map(c => c.label), datasets: [
      { label: 'Delivered', data: clients.map(c => c.delivered), backgroundColor: NV, borderRadius: 4 },
      { label: 'Upcoming', data: clients.map(c => c.upcoming), backgroundColor: GD, borderRadius: 4 },
    ] },
    options: { ...bOpts(false, false), indexAxis: 'y', plugins: { legend: { position: 'top' }, datalabels: dlH() } },
  }), [clients]);

  const fbCfg = useMemo(() => ({ type: 'bar',
    data: { labels: feedback.map(f => f.label), datasets: [{ label: 'Feedback Score', data: feedback.map(f => f.score),
      backgroundColor: feedback.map(f => (f.score >= 4.5 ? GN : f.score >= 4 ? TL : f.score >= 3 ? GD : RD)), borderRadius: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, indexAxis: 'y', layout: { padding: { right: 44 } },
      plugins: { legend: { display: false }, datalabels: { display: true, anchor: 'end', align: 'right', formatter: v => (v > 0 ? v.toFixed(2) : 'N/A'),
        font: { size: 13, weight: '600' }, color: '#374151', clamp: true, padding: { left: 4 } } },
      scales: { x: { min: 0, max: 5, grid: { color: '#EDF0F5' }, ticks: { font: { size: 12 } } }, y: { grid: { display: false }, ticks: { font: { size: 12 }, autoSkip: false } } } },
  }), [feedback]);

  const fbAvg = feedback.length ? feedback.reduce((s, f) => s + f.score, 0) / feedback.length : 0;
  const sDD = trainers.reduce((s, t) => s + t.dd, 0), sDU = trainers.reduce((s, t) => s + t.du, 0);
  const curName = fyLong(CURRENT_FY);
  const r2 = n => fmtNum(Math.round(n * 100) / 100);
  const r2n = n => Math.round(n * 100) / 100;
  // Sessions already over but still Scheduled / Tentative / Re-schedule: counted neither as delivered
  // nor as upcoming until their Status is updated in the Engagement Calendar.
  const staleStatus = live.filter(e => /^(scheduled|tentative|re-?schedule)$/i.test(clean(e.status))
    && hasDate(e) && (/^\d{4}-\d{2}-\d{2}$/.test(e.endDate || '') ? e.endDate : e.startDate) < todayISO);

  /* ═══════════ Operations intelligence (7 Nov 2026) ═══════════ */
  const [drill, setDrill] = useState(null);
  const show = (title, items, how) => setDrill({ title, items, how });
  const [hist, setHist] = useState(false);
  const addD = (iso, n) => { const d = new Date(`${iso}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const endOf = e => (hasDate({ startDate: e.endDate }) && e.endDate >= e.startDate ? e.endDate : e.startDate);
  const in30 = addD(todayISO, 30), in7 = addD(todayISO, 7), ago90 = addD(todayISO, -90), ago60 = addD(todayISO, -60);
  const lyToday = `${+todayISO.slice(0, 4) - 1}${todayISO.slice(4)}`;
  const byDate = (a, b) => String(a.startDate || '9').localeCompare(String(b.startDate || '9'));
  const egList = l => l.slice().sort(byDate).map(e => egItem(e));
  const uniq = (l, by = countBy) => (by === 'projects' ? new Set(l.map(e => clean(e.egId) || `row-${e.sno}`)).size : l.length);

  const ops = useMemo(() => {
    const curDel = cur.filter(isDelivered), curUp = cur.filter(isUpcoming);
    const prevDated = all.filter(e => e.fy === CURRENT_FY - 1 && hasDate(e));
    const prevSame = prevDated.filter(e => isDelivered(e) && e.startDate <= lyToday);
    const next30 = live.filter(e => hasDate(e) && !isCancelled(e) && !isDelivered(e) && e.startDate >= todayISO && e.startDate <= in30).sort(byDate);
    const days = l => l.reduce((t, e) => t + daysOf(e), 0);
    const pax = curDel.reduce((t, e) => t + (Number(e.pax) || 0), 0);
    const scoredCur = curDel.filter(e => feedbackOf(e) != null);
    const awaited = curDel.filter(e => feedbackOf(e) == null && hasDate(e) && endOf(e) <= todayISO);
    const cons = new Map(); [...curDel, ...curUp].forEach(e => consultantsOf(e).forEach(n => { const k = keyOf(n); if (!cons.has(k)) cons.set(k, { label: n, d: 0, list: [] }); const c = cons.get(k); c.d += daysOf(e); c.list.push(e); }));
    return { curDel, curUp, prevDated, prevSame, next30, days, pax, scoredCur, awaited, cons: [...cons.values()].sort((a, b) => b.d - a.d) };
  }, [cur, all, live, countBy]);   // eslint-disable-line react-hooks/exhaustive-deps

  const delYtd = uniq(ops.curDel), prevYtd = uniq(ops.prevSame);
  const delta = ops.prevDated.length && prevYtd ? Math.round(((delYtd - prevYtd) / prevYtd) * 100) : null;
  const avgLoad = ops.cons.length ? ops.cons.reduce((t, c) => t + c.d, 0) / ops.cons.length : 0;
  const clientsServed = new Set(ops.curDel.map(e => keyOf(e.company)).filter(Boolean)).size;

  /* Readiness: flags on the next 30 days */
  const ready = useMemo(() => ops.next30.map(e => {
    const f = [], soon = e.startDate <= in7;
    if (!consultantsOf(e).length) f.push(['No consultant', 'r']);
    if (modeOf(e) === 'unknown') f.push(['No location / mode', soon ? 'r' : 'a']);
    if (/tentative/i.test(clean(e.status))) f.push(['Tentative', soon ? 'r' : 'a']);
    if (!(Number(e.price) > 0)) f.push(['No price', 'a']);
    if (!clean(e.egId)) f.push(['No EG ID', 'a']);
    return { e, f, lvl: f.some(x => x[1] === 'r') ? 'r' : f.length ? 'a' : 'g', soon };
  }), [ops.next30]);   // eslint-disable-line react-hooks/exhaustive-deps
  const readyCount = { r: ready.filter(x => x.lvl === 'r').length, a: ready.filter(x => x.lvl === 'a').length, g: ready.filter(x => x.lvl === 'g').length };

  /* Insights — plain-language alerts worked out from the calendar */
  const insights = useMemo(() => {
    const out = [];
    if (staleStatus.length) out.push({ t: 'r', h: `${staleStatus.length} session${staleStatus.length === 1 ? '' : 's'} ended but still marked Scheduled / Tentative`, s: 'Not counted as delivered until the Status is updated', list: () => egList(staleStatus) });
    if (ready.length && readyCount.r) out.push({ t: 'r', h: `${readyCount.r} of the next ${ready.length} sessions are not ready`, s: 'Missing consultant, location or still tentative inside 7 days', list: () => egList(ready.filter(x => x.lvl === 'r').map(x => x.e)) });
    const load = new Map(); ops.next30.forEach(e => consultantsOf(e).forEach(n => { const k = keyOf(n); if (!load.has(k)) load.set(k, { n, d: 0, l: [] }); const x = load.get(k); x.d += daysOf(e); x.l.push(e); }));
    const ld = [...load.values()].sort((a, b) => b.d - a.d), la = ld.length ? ld.reduce((t, x) => t + x.d, 0) / ld.length : 0;
    if (ld[0] && ld[0].d >= 5 && ld[0].d >= la * 1.5) out.push({ t: 'a', h: `${ld[0].n} carries ${r2(ld[0].d)} days in the next 30`, s: `Team average ${r2(la)} days · check for back-to-back travel and fatigue`, list: () => egList(ld[0].l) });
    const last = new Map(), next = new Set();
    live.forEach(e => { const k = keyOf(e.company); if (!k || !hasDate(e)) return; if (isDelivered(e)) { const o = last.get(k); if (!o || e.startDate > o.d) last.set(k, { d: e.startDate, n: clean(e.company), e }); } else if (isUpcoming(e)) next.add(k); });
    const quiet = [...last.entries()].filter(([k, v]) => v.d < ago90 && !next.has(k)).map(([, v]) => v).sort((a, b) => b.d.localeCompare(a.d));
    if (quiet.length) out.push({ t: 'a', h: `${quiet.length} client${quiet.length === 1 ? ' has' : 's have'} gone quiet`, s: `No session in 90 days and none booked · ${quiet.slice(0, 3).map(q => q.n).join(', ')}${quiet.length > 3 ? '…' : ''}`, list: () => quiet.map(q => ({ ...egItem(q.e), right: `last ${fmtDate(q.d)}` })) });
    const aw = ops.awaited.filter(e => endOf(e) >= ago60);
    if (aw.length) out.push({ t: 'a', h: `${aw.length} delivered session${aw.length === 1 ? '' : 's'} awaiting feedback`, s: 'Delivered in the last 60 days with no score in the Feedback column', list: () => egList(aw) });
    const low = feedback.filter(f => f.n && f.score < 4);
    if (low.length) out.push({ t: 'r', h: `Feedback below 4.0 on ${low.length} program${low.length === 1 ? '' : 's'}`, s: low.slice(0, 3).map(f => `${f.label} ${f.score.toFixed(2)}`).join(' · '), list: () => egList(live.filter(e => low.some(f => keyOf(f.label) === keyOf(clean(e.topic) || '(No topic)')) && feedbackOf(e) != null)) });
    if (delta != null) out.push({ t: delta >= 0 ? 'g' : 'a', h: `Delivery ${delta >= 0 ? 'ahead of' : 'behind'} last year by ${Math.abs(delta)}%`, s: `${delYtd} vs ${prevYtd} ${unit.toLowerCase()} by this date in ${fyShort(CURRENT_FY - 1)}`, list: () => egList(ops.curDel) });
    const wk = new Map(); live.forEach(e => { if (!hasDate(e) || isCancelled(e) || isDelivered(e) || e.startDate < todayISO || e.startDate > addD(todayISO, 56)) return; const d = new Date(`${e.startDate}T00:00:00Z`); const m = addD(e.startDate, -((d.getUTCDay() + 6) % 7)); if (!wk.has(m)) wk.set(m, []); wk.get(m).push(e); });
    const busy = [...wk.entries()].sort((a, b) => b[1].length - a[1].length)[0];
    if (busy && busy[1].length >= 3) out.push({ t: 'n', h: `Busiest week ahead: w/c ${fmtDate(busy[0])}`, s: `${busy[1].length} sessions across ${new Set(busy[1].map(e => keyOf(e.company))).size} clients`, list: () => egList(busy[1]) });
    return out.slice(0, 6);
  }, [staleStatus, ready, readyCount.r, ops, live, feedback, delta, delYtd, prevYtd, unit]);   // eslint-disable-line react-hooks/exhaustive-deps

  /* Delivery rhythm: per month this FY (delivered + booked) vs last FY delivered */
  const MONTHS_FY = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
  const slotOf = iso => (+iso.slice(5, 7) + 8) % 12;
  const rhythm = useMemo(() => {
    const per = (l) => MONTHS_FY.map((_, i) => uniq(l.filter(e => hasDate(e) && slotOf(e.startDate) === i)));
    const d = per(ops.curDel), u = per(ops.curUp), p = per(ops.prevDated.filter(isDelivered));
    const nowI = slotOf(todayISO);
    const cum = []; d.reduce((t, v, i) => { cum[i] = i <= nowI ? t + v : null; return t + v; }, 0);
    const sets = [
      { label: 'Delivered', data: d, backgroundColor: NV, borderRadius: 3, stack: 's', order: 2 },
      { label: 'Booked', data: u, backgroundColor: GD, borderRadius: 3, stack: 's', order: 2 },
    ];
    if (p.some(Boolean)) sets.push({ type: 'line', label: `${fyShort(CURRENT_FY - 1)} delivered`, data: p, borderColor: '#94A3B8', borderDash: [6, 4], borderWidth: 2, pointRadius: 2, tension: 0.3, order: 1, datalabels: { display: false } });
    return { type: 'bar', data: { labels: MONTHS_FY, datasets: sets },
      options: { ...bOpts(true, false), layout: { padding: { top: 18 } }, plugins: { legend: { position: 'top', labels: { boxWidth: 12 } }, datalabels: { display: c => c.dataset.type !== 'line' && c.dataset.data[c.dataIndex] > 0, color: '#fff', font: { size: 10, weight: '700' } } } } };
  }, [ops, countBy]);   // eslint-disable-line react-hooks/exhaustive-deps

  /* Calendar heatmap: sessions running on each day of the FY */
  const heat = useMemo(() => {
    const fyS = `${CURRENT_FY}-04-01`, fyE = `${CURRENT_FY + 1}-03-31`;
    const d0 = new Date(`${fyS}T00:00:00Z`), start = addD(fyS, -((d0.getUTCDay() + 6) % 7));
    const m = new Map();
    cur.forEach(e => { if (!hasDate(e) || isCancelled(e)) return; let d = e.startDate; const end = endOf(e); for (let i = 0; i < 14 && d <= end; i++, d = addD(d, 1)) { if (!m.has(d)) m.set(d, []); m.get(d).push(e); } });
    const cells = []; let d = start;
    while (d <= fyE) { cells.push({ d, l: m.get(d) || [], out: d < fyS }); d = addD(d, 1); }
    const weeks = Math.ceil(cells.length / 7), labels = [];
    cells.forEach((c, i) => { if (c.d.slice(8) === '01' && !c.out) labels.push({ w: Math.floor(i / 7), t: MON[+c.d.slice(5, 7) - 1] }); });
    const max = Math.max(1, ...cells.map(c => c.l.length));
    return { cells, weeks, labels, max, busy: cells.filter(c => c.l.length).length };
  }, [cur]);   // eslint-disable-line react-hooks/exhaustive-deps
  const heatLvl = n => (n === 0 ? 0 : n === 1 ? 1 : n === 2 ? 2 : n <= 4 ? 3 : 4);

  /* Consultant load chart */
  const loadCfg = useMemo(() => {
    const top = trainers.slice(0, 15), avg = trainers.length ? trainers.reduce((t, x) => t + x.dd + x.du, 0) / trainers.length : 0;
    return { avg, n: top.length, cfg: { type: 'bar', data: { labels: top.map(t => (t.dd + t.du >= avg * 1.5 && t.dd + t.du >= 5 ? `⚠ ${t.label}` : t.label)), datasets: [
      { label: 'Delivered days', data: top.map(t => r2n(t.dd)), backgroundColor: NV, borderRadius: 3, stack: 's' },
      { label: 'Booked days', data: top.map(t => r2n(t.du)), backgroundColor: GD, borderRadius: 3, stack: 's' },
    ] }, options: { ...bOpts(true, true), indexAxis: 'y', plugins: { legend: { position: 'top', labels: { boxWidth: 12 } }, datalabels: { display: c => c.dataset.data[c.dataIndex] > 0, color: '#fff', font: { size: 10, weight: '700' } } } } } };
  }, [trainers]);   // eslint-disable-line react-hooks/exhaustive-deps

  /* Client portfolio — this FY */
  const portfolio = useMemo(() => {
    const m = new Map();
    cur.forEach(e => { if (isCancelled(e)) return; const n = clean(e.company), k = keyOf(n); if (!k) return;
      if (!m.has(k)) m.set(k, { name: n, list: [], del: 0, up: 0, days: 0, pax: 0, fb: [], last: '', next: '', months: Array(12).fill(0) });
      const c = m.get(k); c.list.push(e); c.days += daysOf(e); c.pax += Number(e.pax) || 0;
      if (isDelivered(e)) { c.del += 1; if (hasDate(e) && e.startDate > c.last) c.last = e.startDate; const f = feedbackOf(e); if (f != null) c.fb.push(f); }
      else if (isUpcoming(e)) { c.up += 1; if (hasDate(e) && (!c.next || e.startDate < c.next)) c.next = e.startDate; }
      if (hasDate(e)) c.months[slotOf(e.startDate)] += 1; });
    return [...m.values()].map(c => ({ ...c, fbAvg: c.fb.length ? c.fb.reduce((t, x) => t + x, 0) / c.fb.length : null })).sort((a, b) => (b.del + b.up) - (a.del + a.up) || b.days - a.days);
  }, [cur]);   // eslint-disable-line react-hooks/exhaustive-deps
  const showPax = portfolio.some(c => c.pax > 0);

  /* Mix */
  const mixCfg = useMemo(() => {
    const l = [...ops.curDel, ...ops.curUp], ip = l.filter(e => modeOf(e) === 'inPerson').length, vi = l.filter(e => modeOf(e) === 'virtual').length, un = l.length - ip - vi;
    const labels = ['In-Person', 'Virtual', ...(un ? ['Not recorded'] : [])], data = [ip, vi, ...(un ? [un] : [])];
    return { total: l.length, legend: labels.map((x, i) => ({ x, v: data[i], c: [NV, TL, '#CBD5E1'][i] })), cfg: { type: 'doughnut', data: { labels, datasets: [{ data, backgroundColor: [NV, TL, '#CBD5E1'], borderColor: '#fff', borderWidth: 2 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '64%', plugins: { legend: { display: false }, datalabels: { color: '#fff', font: { size: 12, weight: '700' }, formatter: v => (v ? v : '') } } } } };
  }, [ops]);
  const svcCfg = useMemo(() => {
    const m = new Map(); [...ops.curDel, ...ops.curUp].forEach(e => { const lb = clean(e.serviceType) || clean(e.offering) || 'Not recorded'; m.set(lb, (m.get(lb) || 0) + 1); });
    const rows = [...m.entries()].sort((a, b) => (a[0] === 'Not recorded') - (b[0] === 'Not recorded') || b[1] - a[1]).slice(0, 8);
    return { n: rows.length, cfg: { type: 'bar', data: { labels: rows.map(r => r[0]), datasets: [{ label: 'Sessions', data: rows.map(r => r[1]), backgroundColor: rows.map(r => (r[0] === 'Not recorded' ? '#CBD5E1' : PU)), borderRadius: 3 }] },
      options: { ...bOpts(false, true), indexAxis: 'y', plugins: { legend: { display: false }, datalabels: dlH() } } } };
  }, [ops]);

  /* Program quality — only the signal: score, trend, spread, best / at-risk programs, low-score flags */
  const quality = useMemo(() => {
    const sc = cur.filter(e => feedbackOf(e) != null), avgOf = l => (l.length ? l.reduce((t, e) => t + feedbackOf(e), 0) / l.length : null);
    const prev = avgOf(all.filter(e => e.fy === CURRENT_FY - 1 && feedbackOf(e) != null));
    const BANDS = [['4.8 – 5', 4.8, 5.01, 'g'], ['4.5 – 4.7', 4.5, 4.8, 'g'], ['4 – 4.4', 4, 4.5, 't'], ['3 – 3.9', 3, 4, 'a'], ['Below 3', 0, 3, 'r']]
      .map(([lb, a, b, c]) => { const l = sc.filter(e => feedbackOf(e) >= a && feedbackOf(e) < b); return { lb, c, l, n: l.length }; });
    const g = new Map(); sc.forEach(e => { const lb = clean(e.topic) || '(No topic)', k = keyOf(lb); if (!g.has(k)) g.set(k, { lb, l: [] }); g.get(k).l.push(e); });
    const progs = [...g.values()].map(x => ({ ...x, avg: avgOf(x.l) }));
    return { sc, avg: avgOf(sc), prev, bands: BANDS, max: Math.max(1, ...BANDS.map(b => b.n)), hi: sc.length ? Math.round((sc.filter(e => feedbackOf(e) >= 4.5).length / sc.length) * 100) : null,
      top: progs.filter(x => x.avg >= 4.5).sort((a, b) => b.avg - a.avg || b.l.length - a.l.length).slice(0, 3),
      risk: progs.filter(x => x.avg < 4).sort((a, b) => a.avg - b.avg).slice(0, 3),
      flags: sc.filter(e => feedbackOf(e) < 4).sort((a, b) => String(b.startDate).localeCompare(String(a.startDate))).slice(0, 4) };
  }, [cur, all]);   // eslint-disable-line react-hooks/exhaustive-deps
  const qTone = v => (v == null ? '' : v >= 4.5 ? 'g' : v >= 4 ? 't' : v >= 3 ? 'a' : 'r');

  const Spark = ({ v }) => { const mx = Math.max(1, ...v); return (
    <svg width="72" height="18" viewBox="0 0 72 18" aria-hidden="true">{v.map((x, i) => <rect key={i} x={i * 6} y={18 - (x / mx) * 16 - 1} width="4" height={(x / mx) * 16 + 1} rx="1" fill={i <= slotOf(todayISO) ? NV : GD} opacity={x ? 1 : 0.18} />)}</svg>); };

  return (
    <div className="erd ops" style={{ opacity: refreshing ? 0.85 : 1, transition: 'opacity .2s' }}>
      <div className="pg-hdr"><h2>Operations</h2><p>Delivery readiness, capacity, client activity &amp; quality — {curName}</p></div>
      <SourceNote live={`${fyLong(LIVE_FROM_FY)} onward from the Engagement Calendar`} fixed="earlier years (History section) from Dashboard Report Data (12 Oct 2026)" />

      <div className="erd-bar">
        <label>Count by</label>
        <div className="erd-seg">
          {[['projects', 'Projects (EG ID)'], ['sessions', 'Sessions']].map(([k, l]) => (
            <button key={k} type="button" className={countBy === k ? 'on' : ''} aria-pressed={countBy === k} onClick={() => setCountBy(k)}>{l}</button>
          ))}
        </div>
        {refreshing && <span style={{ fontSize: 13, color: '#00808C', fontWeight: 700 }}>⟳ Updating…</span>}
      </div>

      <div className="kg g6">
        <Kpi tone="nv" label={`Delivered · ${fyShort(CURRENT_FY)}`} list={() => egList(ops.curDel)} value={delYtd}
          sub={delta != null ? `${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}% vs ${prevYtd} by this date last FY` : `${unit.toLowerCase()} completed this FY`} tag={delta != null ? (delta >= 0 ? 'Ahead' : 'Behind') : undefined} tagTone={delta >= 0 ? 'up' : 'bad'}
          how={`Status = Delivered, start date in this FY, counted once per ${countBy === 'projects' ? 'EG ID' : 'calendar row'}; compared with last FY's delivered rows up to the same date.`} />
        <Kpi tone="tl" label="Training Days" list={() => egList(ops.curDel)} value={r2(ops.days(ops.curDel))} sub={`${r2(ops.days(ops.curUp))} days booked ahead`} how="Sum of the Day column of this FY's delivered sessions (once per session, not per consultant)." />
        <Kpi tone="gn" label={ops.pax ? 'Participants Trained' : 'Clients Served'} list={() => egList(ops.curDel)} value={ops.pax ? fmtNum(ops.pax) : clientsServed} sub={ops.pax ? `${clientsServed} clients served` : 'with a delivered session this FY'} how={ops.pax ? 'Sum of No of Participants on delivered sessions this FY.' : 'Distinct companies with a delivered session this FY (No of Participants is not filled in the calendar).'} />
        <Kpi tone="gd" label="Next 30 Days" list={() => egList(ops.next30)} value={ops.next30.length} sub={`${ops.next30.filter(e => e.startDate <= in7).length} this week · ${r2(ops.days(ops.next30))} days`} tag={readyCount.r ? `${readyCount.r} not ready` : undefined} tagTone="bad" how="Sessions starting today → 30 days ahead that are not cancelled / delivered." />
        <Kpi tone="pu" label="Feedback Avg" list={() => egList(ops.scoredCur)} value={ops.scoredCur.length ? (ops.scoredCur.reduce((t, e) => t + feedbackOf(e), 0) / ops.scoredCur.length).toFixed(2) : '--'} sub={`${ops.scoredCur.length} scored · ${ops.awaited.length} awaited`} how="Average Feedback (0–5) of this FY's delivered sessions; awaited = delivered with no score yet." />
        <Kpi tone="rd" label="Consultant Load" list={() => ops.cons.map(c => ({ name: c.label, sub: `${c.list.length} sessions`, right: `${r2(c.d)} days` }))} value={ops.cons.length} sub={ops.cons.length ? `avg ${r2(avgLoad)} days · top ${ops.cons[0].label} ${r2(ops.cons[0].d)}` : 'no consultants this FY'} how="Consultants with delivered or booked days this FY; days credited to every consultant on the session." />
      </div>

      {insights.length > 0 && (
        <div className="op-ins">
          {insights.map((x, i) => (
            <button key={i} type="button" className={`op-in ${x.t}`} onClick={() => show(x.h, x.list, x.s)}>
              <span className="op-in-dot" /><span className="op-in-tx"><b>{x.h}</b><em>{x.s}</em></span>
            </button>
          ))}
        </div>
      )}

      <div className="cg c1">
        <div className="card"><div className="sl-head"><div><h3>Delivery Readiness — Next 30 Days</h3><div className="cs">{ready.length} sessions · tap a row for details, double-tap in the list to edit in the Engagement Calendar</div></div>
          <div className="op-rc"><span className="r">{readyCount.r} not ready</span><span className="a">{readyCount.a} check</span><span className="g">{readyCount.g} ready</span></div></div>
          {ready.length === 0 ? <div className="erd-empty">Nothing booked in the next 30 days</div> : (
            <div className="tbl-x" style={{ maxHeight: 360, overflowY: 'auto', marginTop: 10 }}>
              <table className="mt op-rt">
                <thead><tr><th></th><th>Date</th><th>Client</th><th>Program</th><th>Consultants</th><th>Mode</th><th className="nr">Days</th><th>Flags</th></tr></thead>
                <tbody>{ready.map(({ e, f, lvl, soon }, i) => (
                  <tr key={(e.engagementKey || e.sno || '') + '-' + i} className="sl-click" onClick={() => show(`${clean(e.company)} · ${fmtDate(e.startDate)}`, [egItem(e)], f.length ? `Flags: ${f.map(x => x[0]).join(', ')}` : 'Ready — consultant, location and status in place.')}>
                    <td><span className={`op-lv ${lvl}`} /></td>
                    <td style={{ whiteSpace: 'nowrap', fontWeight: soon ? 700 : 500 }}>{fmtDate(e.startDate)}{endOf(e) !== e.startDate ? ` – ${+endOf(e).slice(8)}` : ''}</td>
                    <td style={{ fontWeight: 600 }}>{clean(e.company) || '—'}</td><td>{clean(e.topic) || '—'}</td>
                    <td>{consultantsOf(e).join(', ') || <span className="op-miss">—</span>}</td>
                    <td>{{ inPerson: 'In-Person', virtual: 'Virtual', unknown: '—' }[modeOf(e)]}</td>
                    <td className="nr">{r2(daysOf(e))}</td>
                    <td>{f.length ? f.map(x => <span key={x[0]} className={`op-fl ${x[1]}`}>{x[0]}</span>) : <span className="op-fl g">Ready</span>}</td>
                  </tr>))}</tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="cg c11">
        <div className="card"><h3>Delivery Rhythm — {curName}</h3><div className="cs">{unit} per month · delivered vs booked{rhythm.data.datasets.length > 2 ? ` · dashed = ${fyShort(CURRENT_FY - 1)} delivered` : ''}</div>
          <ChartBox config={rhythm} className="ch-wrap tall" title="Delivery rhythm" how="Engagement Calendar sessions by start month: Delivered = Status Delivered, Booked = Scheduled / Tentative / Re-schedule from today."
            listFor={(lb, ds) => { const i = MONTHS_FY.indexOf(lb); const pool = /deliv/i.test(ds) && !/^FY|\d/.test(ds) ? ops.curDel : /book/i.test(ds) ? ops.curUp : ops.prevDated.filter(isDelivered); return egList(pool.filter(e => hasDate(e) && slotOf(e.startDate) === i)); }} /></div>
        <div className="card"><h3>Session Calendar — {curName}</h3><div className="cs">Each square = a day · shade = sessions running that day · {heat.busy} active days · tap a day</div>
          <div className="op-hm-wrap">
            <div className="op-hm-m" style={{ gridTemplateColumns: `repeat(${heat.weeks}, 1fr)` }}>{heat.labels.map(x => <span key={x.t + x.w} style={{ gridColumn: x.w + 1 }}>{x.t}</span>)}</div>
            <div className="op-hm" style={{ gridTemplateColumns: `repeat(${heat.weeks}, 1fr)` }}>
              {heat.cells.map(c => <i key={c.d} className={`l${c.out ? 'x' : heatLvl(c.l.length)}${c.d === todayISO ? ' now' : ''}${c.l.length ? ' sl-click' : ''}`} title={c.out ? '' : `${fmtDate(c.d)} · ${c.l.length} session${c.l.length === 1 ? '' : 's'}`}
                onClick={c.l.length ? () => show(`Sessions on ${fmtDate(c.d)}`, egList(c.l), 'Sessions running on this day (start → end date).') : undefined} />)}
            </div>
            <div className="op-hm-lg">Less {[0, 1, 2, 3, 4].map(n => <i key={n} className={`l${n}`} />)} More <span>· outlined = today</span></div>
          </div>
        </div>
      </div>

      <div className="cg c11">
        <div className="card"><h3>Consultant Load — {curName}</h3><div className="cs">Delivered + booked days · team average {r2(loadCfg.avg)} days · ⚠ = 1.5× average or more</div>
          {loadCfg.n ? <ChartBox config={loadCfg.cfg} height={heightFor(loadCfg.n, 28, 260)} title="Consultant load" how="Day column credited to every consultant on the session; Delivered = Status Delivered, Booked = upcoming."
            listFor={lb => { const n = keyOf(String(lb).replace(/^⚠\s*/, '')); return egList([...ops.curDel, ...ops.curUp].filter(e => consultantsOf(e).some(c => keyOf(c) === n))); }} /> : <div className="erd-empty">No consultant days yet</div>}
        </div>
        <div className="card flex-card"><h3>Client Portfolio — {curName}</h3><div className="cs">{portfolio.length} active clients · sessions, days{showPax ? ', participants' : ''}, feedback and next date · bars = sessions per month (Apr → Mar)</div>
          <div className="tbl-x" style={{ maxHeight: 420, overflowY: 'auto', marginTop: 10 }}>
            <table className="mt op-pt">
              <thead><tr><th>Client</th><th className="nr">Done</th><th className="nr">Booked</th><th className="nr">Days</th>{showPax && <th className="nr">Pax</th>}<th className="nr">Feedback</th><th>Next</th><th>Trend</th></tr></thead>
              <tbody>{portfolio.length === 0 ? <tr><td colSpan={8} className="erd-empty">No clients yet</td></tr> : portfolio.map(c => (
                <tr key={c.name} className="sl-click" onClick={() => show(`${c.name} · ${fyShort(CURRENT_FY)}`, egList(c.list), 'This FY\'s sessions for the client (cancelled / on hold excluded).')}>
                  <td style={{ fontWeight: 600 }}>{c.name}</td><td className="nr">{c.del}</td><td className="nr">{c.up || '—'}</td><td className="nr">{r2(c.days)}</td>{showPax && <td className="nr">{c.pax || '—'}</td>}
                  <td className="nr" style={{ fontWeight: 700, color: c.fbAvg == null ? '#9CA3AF' : c.fbAvg >= 4.5 ? '#0AC44B' : c.fbAvg >= 4 ? '#2D3047' : '#E98272' }}>{c.fbAvg == null ? '—' : c.fbAvg.toFixed(2)}</td>
                  <td style={{ whiteSpace: 'nowrap' }}>{c.next ? fmtDate(c.next) : <span className="op-miss">none booked</span>}</td><td><Spark v={c.months} /></td>
                </tr>))}</tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="cg c11">
        <div className="card"><h3>Delivery Mode</h3><div className="cs">{mixCfg.total} sessions this FY (delivered + booked)</div>
          <div className="op-donut"><ChartBox config={mixCfg.cfg} height={190} title="Delivery mode" how="Location VILT / Virtual / Online → Virtual, any other place → In-Person." listFor={lb => egList([...ops.curDel, ...ops.curUp].filter(e => ({ 'In-Person': 'inPerson', Virtual: 'virtual', 'Not recorded': 'unknown' })[lb] === modeOf(e)))} />
            <div className="op-dl">{mixCfg.legend.map(x => <span key={x.x}><i style={{ background: x.c }} />{x.x} <b>{x.v}</b> <em>{mixCfg.total ? Math.round((x.v / mixCfg.total) * 100) : 0}%</em></span>)}</div></div>
        </div>
        <div className="card"><h3>Service Mix</h3><div className="cs">Sessions by Service Type (else Offering) · this FY</div>
          {svcCfg.n ? <ChartBox config={svcCfg.cfg} height={heightFor(svcCfg.n, 26, 200)} title="Service mix" how="Service Type of each session (Offering when Service Type is blank)." listFor={lb => egList([...ops.curDel, ...ops.curUp].filter(e => (clean(e.serviceType) || clean(e.offering) || 'Not recorded') === lb))} /> : <div className="erd-empty">No sessions yet</div>}
        </div>
      </div>

      <div className="cg c1">
        <div className="card"><div className="sl-head"><div><h3>Program Quality — {curName}</h3><div className="cs">{quality.sc.length} scored sessions · {ops.awaited.length} awaiting a score · only what needs attention is flagged</div></div>
          {ops.awaited.length > 0 && <button type="button" className="op-fl a sl-click" style={{ border: 0, font: 'inherit', fontSize: 12 }} onClick={() => show('Awaiting feedback', egList(ops.awaited), 'Delivered this FY with no score in the Feedback column.')}>{ops.awaited.length} awaiting feedback</button>}</div>
          {quality.avg == null ? <div className="erd-empty">No feedback scores this FY yet</div> : (
            <div className="op-q">
              <div className="op-q-score">
                <svg viewBox="0 0 120 120" width="132" height="132" aria-hidden="true"><circle cx="60" cy="60" r="50" fill="none" stroke="#EEF1F5" strokeWidth="12" />
                  <circle cx="60" cy="60" r="50" fill="none" className={`op-q-ring ${qTone(quality.avg)}`} strokeWidth="12" strokeLinecap="round" strokeDasharray={`${(quality.avg / 5) * 314} 314`} transform="rotate(-90 60 60)" /></svg>
                <div className="op-q-num"><b>{quality.avg.toFixed(2)}</b><span>out of 5</span></div>
                <div className="op-q-sub">{quality.prev != null && <span className={quality.avg >= quality.prev ? 'up' : 'dn'}>{quality.avg >= quality.prev ? '▲' : '▼'} {Math.abs(quality.avg - quality.prev).toFixed(2)} vs {fyShort(CURRENT_FY - 1)}</span>}
                  {quality.hi != null && <span>{quality.hi}% scored 4.5+</span>}</div>
              </div>
              <div className="op-q-dist">
                <div className="sl-sub">Score spread</div>
                {quality.bands.map(b => (
                  <div key={b.lb} className={`op-q-band${b.n ? ' sl-click' : ''}`} onClick={b.n ? () => show(`Feedback ${b.lb}`, egList(b.l), 'Delivered sessions this FY with a score in this band.') : undefined}>
                    <span className="op-q-lb">{b.lb}</span><span className="op-q-tr"><i className={b.c} style={{ width: `${(b.n / quality.max) * 100}%` }} /></span><span className="op-q-n">{b.n}</span>
                  </div>))}
              </div>
              <div className="op-q-lists">
                <div className="sl-sub">Needs attention</div>
                {quality.risk.length === 0 ? <div className="op-q-ok">✓ No program averaging below 4.0</div> : quality.risk.map(x => (
                  <div key={x.lb} className="op-q-row r sl-click" onClick={() => show(x.lb, egList(x.l), 'Scored sessions of this program this FY.')}><span>{x.lb}</span><b>{x.avg.toFixed(2)}</b><em>{x.l.length}×</em></div>))}
                {quality.flags.length > 0 && <div className="op-q-flags">{quality.flags.map((e, i) => (
                  <span key={i} className="op-fl r sl-click" onClick={() => show(`${clean(e.company)} · ${clean(e.topic)}`, [egItem(e)], 'Session scored below 4.0.')}>{clean(e.company)} · {feedbackOf(e).toFixed(1)}</span>))}</div>}
                <div className="sl-sub" style={{ marginTop: 12 }}>Top performers</div>
                {quality.top.length === 0 ? <div className="op-q-ok muted">No program averaging 4.5+ yet</div> : quality.top.map(x => (
                  <div key={x.lb} className="op-q-row g sl-click" onClick={() => show(x.lb, egList(x.l), 'Scored sessions of this program this FY.')}><span>{x.lb}</span><b>{x.avg.toFixed(2)}</b><em>{x.l.length}×</em></div>))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="card op-hist">
        <button type="button" className="op-hist-h" onClick={() => setHist(h => !h)} aria-expanded={hist}><span>History &amp; year-on-year</span><em>{hist ? 'Hide' : 'Show'} FY trend, delivery mode by FY, consultant and client year-on-year</em><b>{hist ? '−' : '+'}</b></button>
        {hist && (<>
          <div className="cg c11">
            <div className="card"><h3>Project Trend by FY</h3><div className="cs">Total delivered and upcoming per financial year</div><ChartBox config={trendCfg} /></div>
            <div className="card"><h3>Delivery Mode by FY</h3><div className="cs">In-Person vs Virtual</div><ChartBox config={modeCfg} /></div>
          </div>
          <div className="cg c11">
            <div className="card"><h3>Consultant Days — Year on Year</h3><div className="cs">Delivered days per FY (current FY includes upcoming) · top 15</div>
              {compare.cons.rows.length ? <ChartBox config={compare.cons.cfg} height={heightFor(compare.cons.rows.length, 44, 300)} /> : <div className="erd-empty">No consultant data</div>}</div>
            <div className="card"><h3>Client Status — Year on Year</h3><div className="cs">Projects delivered per FY (current FY includes upcoming) · top 15</div>
              {compare.cli.rows.length ? <ChartBox config={compare.cli.cfg} height={heightFor(compare.cli.rows.length, 44, 300)} /> : <div className="erd-empty">No client data</div>}</div>
          </div>
        </>)}
      </div>
      {drill && <KpiListModal title={drill.title} items={drill.items} how={drill.how} onClose={() => setDrill(null)} />}
    </div>
  );
}
