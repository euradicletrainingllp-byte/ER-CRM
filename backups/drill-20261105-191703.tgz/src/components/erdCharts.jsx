/**
 * Shared Chart.js setup for the Operations and Solutioning dashboards.
 * Charts, colours and label styles match the standalone "EuRadicle Dashboard" HTML report.
 * Chart.js + the datalabels plugin are loaded once from cdnjs (same versions as the HTML report).
 */
import { useEffect, useRef, useState } from 'react';
import './erdDashboard.css';
import KpiListModal, { useDrill, drillItems } from './KpiListModal.jsx';

const SCRIPTS = [
  ['Chart', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js'],
  ['ChartDataLabels', 'https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-datalabels/2.2.0/chartjs-plugin-datalabels.min.js'],
];
let loading = null;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src; s.async = false;
    s.onload = resolve;
    s.onerror = () => reject(new Error('could not download ' + src.split('/').pop()));
    document.head.appendChild(s);
  });
}

export function loadChartJs() {
  if (!loading) {
    loading = (async () => {
      for (const [g, src] of SCRIPTS) if (!window[g]) await loadScript(src);
      const Chart = window.Chart;
      if (!Chart.__erdConfigured) {
        Chart.defaults.font.family = "'Segoe UI',system-ui,sans-serif";
        Chart.defaults.font.size = 13;
        Chart.defaults.color = '#374151';
        Chart.defaults.plugins.legend.labels.usePointStyle = true;
        Chart.defaults.plugins.legend.labels.pointStyleWidth = 10;
        Chart.defaults.plugins.legend.labels.boxHeight = 9;
        Chart.defaults.plugins.legend.labels.font = { size: 13 };
        Chart.defaults.plugins.tooltip.titleFont = { size: 13, weight: '700' };
        Chart.defaults.plugins.tooltip.bodyFont = { size: 13 };
        Chart.defaults.datasets.bar.categoryPercentage = 0.55;
        Chart.defaults.datasets.bar.barPercentage = 0.8;
        Chart.defaults.datasets.bar.maxBarThickness = 46;
        Chart.register(window.ChartDataLabels);
        Chart.defaults.plugins.datalabels = { display: false };
        Chart.__erdConfigured = true;
      }
      return Chart;
    })().catch(e => { loading = null; throw e; });
  }
  return loading;
}

/** One Chart.js chart. `config` must be memoised — a new object redraws the chart. */
export function ChartBox({ config, className = 'ch-wrap', height, listFor, title }) {
  const canvas = useRef(null);
  const [err, setErr] = useState(null);
  const [pick, setPick] = useState(null);
  const drill = useDrill();
  const lf = useRef(listFor); lf.current = listFor;
  const dr = useRef(drill); dr.current = drill;
  useEffect(() => {
    let chart = null, dead = false;
    loadChartJs()
      .then(Chart => {
        if (dead || !canvas.current) return;
        const onClick = (ev, els, ch) => {
          const el = els?.[0]; if (!el) return;
          const label = String(ch.data.labels?.[el.index] ?? ''), ds = ch.data.datasets[el.datasetIndex] || {};
          const raw = ds.data?.[el.index], value = typeof raw === 'object' && raw ? (raw.y ?? raw.x) : raw;
          const items = lf.current ? lf.current(label, ds.label || '', value)
            : drillItems(dr.current, label, ds.label || '') ||
            // default: every series' value at the tapped point
              ch.data.datasets.map(d => { const r = d.data?.[el.index]; return { name: d.label || label, sub: label, right: r == null ? '—' : String(typeof r === 'object' ? (r.y ?? r.x) : r) }; });
          setPick({ title: [label, ds.label].filter(Boolean).join(' · '), items });
        };
        const opts = { ...(config.options || {}), onClick, onHover: (ev, els) => { ev.native && (ev.native.target.style.cursor = els.length ? 'pointer' : 'default'); } };
        chart = new Chart(canvas.current.getContext('2d'), { ...config, options: opts });
      })
      .catch(e => setErr(e.message));
    return () => { dead = true; chart?.destroy(); };
  }, [config]);
  return (
    <div className={className} style={height ? { height } : undefined}>
      {err ? <div className="erd-err">Charts could not load ({err}). Check the internet connection and refresh.</div>
           : <canvas ref={canvas} />}
      {pick && <KpiListModal title={title ? `${title} — ${pick.title}` : pick.title} items={pick.items} onClose={() => setPick(null)} />}
    </div>
  );
}

/* ─── Palette (same as the HTML report) ─── */
export const NV = '#1B2A4A', TL = '#00808C', GD = '#E8A020', GN = '#2DBD7E', PU = '#7C5CBF', RD = '#E05252';
const DL = '#374151';
const GRID = '#EDF0F5';

/* ─── Formatting ─── */
export const fmtNum = n => (Number.isInteger(n) ? String(n) : Number(n || 0).toFixed(2));
export function fmtInr(v) {
  v = Math.abs(v || 0);
  if (v >= 1e7) return 'Rs.' + (v / 1e7).toFixed(2) + 'Cr';
  if (v >= 1e5) return 'Rs.' + (v / 1e5).toFixed(2) + 'L';
  if (v >= 1e3) return 'Rs.' + (v / 1e3).toFixed(1) + 'K';
  return 'Rs.' + Math.round(v);
}
// rows get extra room so 12–13px labels never overlap
/** Compact ₹ for axes and labels inside bars: 2.40Cr, 51.0L, 94.5K */
export function fmtShort(v) {
  v = Math.abs(v || 0);
  if (v >= 1e7) return (v / 1e7).toFixed(2) + 'Cr';
  if (v >= 1e5) return (v / 1e5).toFixed(1) + 'L';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + 'K';
  return String(Math.round(v));
}
/** Show a ₹ axis as 1Cr / 50L instead of 10,000,000. */
export function inrAxis(opts, axis) {
  opts.scales[axis] = { ...opts.scales[axis], ticks: { ...(opts.scales[axis].ticks || {}), callback: v => fmtShort(v) } };
  return opts;
}
export const heightFor = (n, per = 22, min = 220) => Math.max(min + 40, Math.round(n * per * 1.25));

/* ─── Datalabel styles ─── */
export const dlNum   = () => ({ display: true, anchor: 'end', align: 'end', formatter: v => (v > 0 ? v : ''), font: { size: 13, weight: '600' }, color: DL, padding: 2 });
export const dlInr   = () => ({ display: true, anchor: 'end', align: 'end', formatter: v => (v > 0 ? fmtInr(v) : ''), font: { size: 12, weight: '600' }, color: DL, padding: 2 });
export const dlStack = () => ({ display: ctx => ctx.dataset.data[ctx.dataIndex] > 0, anchor: 'center', align: 'center', formatter: v => (v > 0 ? v : ''), font: { size: 13, weight: '700' }, color: '#fff' });
export const dlStackInr = () => ({ display: ctx => ctx.dataset.data[ctx.dataIndex] > 0, anchor: 'center', align: 'center', formatter: v => (v > 0 ? fmtShort(v) : ''), font: { size: 11, weight: '700' }, color: '#fff' });
export const dlH     = () => ({ display: true, anchor: 'end', align: 'right', formatter: v => (v > 0 ? fmtNum(v) : ''), font: { size: 13, weight: '600' }, color: DL, clamp: true, padding: { left: 4 } });
export const dlInrH  = () => ({ display: true, anchor: 'end', align: 'right', formatter: v => (v > 0 ? fmtInr(v) : ''), font: { size: 12, weight: '600' }, color: DL, clamp: true, padding: { left: 4 } });

/* ─── Axis options ─── */
export function bOpts(stacked, horiz) {
  return {
    responsive: true, maintainAspectRatio: false,
    layout: { padding: { right: horiz ? 44 : 0 } },
    plugins: { legend: { position: 'top' } },
    scales: {
      x: { stacked, grid: { display: !!horiz, color: GRID }, ticks: { font: { size: 12 } } },
      y: { stacked, grid: { color: GRID, display: !horiz }, ticks: { font: { size: 12 } } },
    },
  };
}

/* ─── Date / FY helpers ─── */
export const pad2 = n => String(n).padStart(2, '0');
const localToday = () => { const t = new Date(); return `${t.getFullYear()}-${pad2(t.getMonth() + 1)}-${pad2(t.getDate())}`; };
export const fyStartOf = iso => { const y = +iso.slice(0, 4), m = +iso.slice(5, 7); return m >= 4 ? y : y - 1; };
// Live bindings: every module that imports these sees the new value after refreshToday(),
// so a dashboard left open past midnight (or past 31 March) moves to the new day / FY.
export let todayISO = localToday();
export let CURRENT_FY = fyStartOf(todayISO);
/** Re-read the date. Returns true when the day changed (the Dashboard then redraws its tabs). */
export function refreshToday() {
  const t = localToday();
  if (t === todayISO) return false;
  todayISO = t;
  CURRENT_FY = fyStartOf(t);
  return true;
}
export const fyShort = y => `${y}-${pad2((y + 1) % 100)}`;          // 2026-27
export const fyLong  = y => `FY ${y}-${pad2((y + 1) % 100)}`;       // FY 2026-27
export const fyTiny  = y => `FY ${pad2(y % 100)}-${pad2((y + 1) % 100)}`; // FY 26-27
export const clean = v => String(v ?? '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
export const keyOf = v => clean(v).toLowerCase();

/** Small KPI tile, same look as the HTML report. `how` = one line saying how the figure is calculated. */
export function Kpi({ tone, label, value, sub, tag, tagTone = 'info', how, list, listSub }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`kpi ${tone}`} onClick={list ? () => setOpen(true) : undefined} style={list ? { cursor: 'pointer' } : undefined} title={list ? 'Click to see the list' : undefined}>
      {open && <div onClick={e => e.stopPropagation()}><KpiListModal title={label} sub={listSub} items={list} onClose={() => setOpen(false)} /></div>}
      <div className="lb">{label}</div>
      <div className="vl">{value}</div>
      <div className="sb">{sub}</div>
      {tag && <span className={`tg ${tagTone}`}>{tag}</span>}
      {how && <div className="how" title={how}>How: {how}</div>}
    </div>
  );
}

/** Note under the page header saying which years are live. */
export function SourceNote({ live, fixed }) {
  return (
    <div className="erd-src">
      <span className="erd-live-dot" /> <strong>Live:</strong> {live}
      <span className="erd-src-sep">·</span>
      <strong>Fixed:</strong> {fixed}
    </div>
  );
}
