import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication, EventType, InteractionType } from '@azure/msal-browser';
import { msalConfig } from './config/authConfig.js';
import AuthGuard          from './components/AuthGuard.jsx';
import Sidebar            from './components/Sidebar.jsx';
import TopBar             from './components/TopBar.jsx';
import Dashboard          from './pages/Dashboard.jsx';
import FounderDashboard   from './pages/FounderDashboard.jsx';
import LeadTracker        from './pages/LeadTracker.jsx';
import VendorTracker      from './pages/VendorTracker.jsx';
import TaskTracker        from './pages/TaskTracker.jsx';
import ConsultantDirectory from './pages/ConsultantDirectory.jsx';
import POTracker from './pages/POTracker.jsx';
import ClientDirectory from './pages/ClientDirectory.jsx';
import TaskFloat          from './components/TaskFloat.jsx';
import { TourProvider }   from './components/tour/TourProvider.jsx';
import EngagementPage     from './pages/EngagementPage.jsx';
import OpsChecklist          from './pages/OpsChecklist.jsx';
import ContentDevelopmentTracker from './pages/ContentDevelopmentTracker.jsx';
import FinanceTracker        from './pages/FinanceTracker.jsx';
import SolutionTracker        from './pages/SolutionTracker.jsx';
import AdminPage             from './pages/AdminPage.jsx';
import NoAccessPage       from './pages/NoAccessPage.jsx';
import { PermissionsProvider } from './context/PermissionsContext.jsx';
import { usePermissions } from './hooks/usePermissions.js';
import { logEvent, setAuditUser, firstTimeThisSession, AUDIT_OPTIONS } from './services/auditLogger.js';
import './styles/index.css';

/**
 * PermissionRoute — wraps a page with an access check.
 * Shows NoAccessPage if the signed-in user lacks access to that page key.
 * Admins always pass through.
 */
function PermissionRoute({ page, also = [], children }) {
  const { isAdmin, canAccess } = usePermissions();
  if (isAdmin || (canAccess(page) && also.every(p => canAccess(p)))) return children;
  return <DeniedPage page={page} />;
}

// Activity log: record the blocked page, then show the normal No Access page
function DeniedPage({ page }) {
  useEffect(() => {
    logEvent({ Category: 'ACCESS', Action: 'PAGE_DENIED', Module: page, RecordLabel: window.location.pathname, Result: 'FAILED' });
  }, [page]);
  return <NoAccessPage page={page} />;
}

// Activity log: page key for each route (used for PAGE_VIEW rows)
const ROUTE_MODULE = {
  '/': 'dashboard', '/founder': 'founder', '/tasks': 'tasks', '/leads': 'leads', '/vendors': 'vendors', '/consultants': 'consultants', '/po': 'po', '/clients': 'clients', '/bd-tracker': 'bd', '/engagement': 'engagement', '/ops': 'ops', '/finance': 'finance',
  '/content-dev': 'content-dev', '/solution': 'solution', '/er-calendar': 'engagement', '/admin': 'permissions',
};

// Initialise MSAL once at module level.
// IMPORTANT: Do NOT call getAllAccounts() or any other MSAL method here —
// the instance is not initialized yet. MsalProvider calls initialize()
// internally. Account restoration happens inside AuthGuard via useEffect.
const msalInstance = new PublicClientApplication(msalConfig);

// addEventCallback is safe before initialize() — it just queues the listener.
msalInstance.addEventCallback(event => {
  if (event.eventType === EventType.LOGIN_SUCCESS && event.payload?.account) {
    msalInstance.setActiveAccount(event.payload.account);
  }
});

// Activity log: sign-in success / failure (never affects sign-in itself)
msalInstance.addEventCallback(event => {
  try {
    if (event.eventType === EventType.LOGIN_SUCCESS) {
      setAuditUser(event.payload?.account || event.payload);
      firstTimeThisSession('start');   // so AuthGuard does not also log SESSION_RESUMED
      logEvent({
        Category: 'AUTH', Module: 'auth',
        Action: event.interactionType === InteractionType.Silent ? 'LOGIN_SSO' : 'LOGIN',
      });
    } else if (
      event.eventType === EventType.ACQUIRE_TOKEN_FAILURE &&
      event.interactionType !== InteractionType.Silent      // silent SSO misses are normal
    ) {
      logEvent({
        Category: 'AUTH', Action: 'LOGIN_FAILED', Module: 'auth', Result: 'FAILED',
        ErrorMessage: event.error?.errorCode || event.error?.message || 'Sign-in failed',
      });
    }
  } catch { /* ignore */ }
});

function Shell() {
  const location = useLocation();
  const [lastRefreshed, setLastRefreshed] = useState('');
  const [loading,       setLoading]       = useState(false);

  // Activity log: one PAGE_VIEW row per page opened
  useEffect(() => {
    if (!AUDIT_OPTIONS.logPageViews) return;
    logEvent({ Category: 'ACCESS', Action: 'PAGE_VIEW', Module: ROUTE_MODULE[location.pathname] || 'other', RecordLabel: location.pathname });
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <TopBar path={location.pathname} lastRefreshed={lastRefreshed} loading={loading} />
        <main className="page-content">
          <Routes>
            <Route path="/" element={
              <PermissionRoute page="dashboard">
                <Dashboard onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/founder" element={
              <PermissionRoute page="founder">
                <FounderDashboard onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/tasks" element={
              <PermissionRoute page="tasks">
                <TaskTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/leads" element={
              <PermissionRoute page="leads">
                <LeadTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/vendors" element={
              <PermissionRoute page="vendors">
                <VendorTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/clients" element={
              <PermissionRoute page="clients">
                <ClientDirectory onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/po" element={
              <PermissionRoute page="po">
                <POTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/consultants" element={
              <PermissionRoute page="consultants">
                <ConsultantDirectory onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/bd-tracker" element={
              <PermissionRoute page="bd">
                <SolutionTracker key="bd" view="bd" onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/engagement" element={
              <PermissionRoute page="engagement">
                <EngagementPage onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/ops" element={
              <PermissionRoute page="ops">
                <OpsChecklist onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/finance" element={
              <PermissionRoute page="finance">
                <FinanceTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/content-dev" element={
              <PermissionRoute page="content-dev">
                <ContentDevelopmentTracker onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            <Route path="/solution" element={
              <PermissionRoute page="solution">
                <SolutionTracker key="sol" view="sol" onRefreshed={setLastRefreshed} />
              </PermissionRoute>
            } />
            {/* ER Calendar is now the "Calendar" view of the Engagement Calendar — keep old links working */}
            <Route path="/er-calendar" element={<Navigate to="/engagement?view=calendar" replace />} />
            <Route path="/admin" element={<AdminPage />} />
          </Routes>
        </main>
      </div>
      {/* Floating "My Tasks" panel — on every page for people with Project Management access */}
      <TaskFloat />
    </div>
  );
}

export default function App() {
  return (
    <MsalProvider instance={msalInstance}>
      <BrowserRouter>
        <AuthGuard>
          <PermissionsProvider>
            {/* Platform Tour: welcome screen + guided spotlight tour, shaped by each person's access */}
            <TourProvider>
              <Shell />
            </TourProvider>
          </PermissionsProvider>
        </AuthGuard>
      </BrowserRouter>
    </MsalProvider>
  );
}
